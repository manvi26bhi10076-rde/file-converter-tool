"""
app.py
------
Simple File Converter Web Tool
First-Year Academic Project — Python Essentials

This script runs a simple local web server using Python's built-in
standard library (http.server). It allows the user to:
1. Open the application in their browser at http://localhost:8000
2. Choose a file or paste text
3. Select one of the 6 supported conversions
4. View conversion statistics and preview the output
5. Download or save the converted file

To run:
    python app.py
"""

import os
import urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler

# Import our custom converter class and choices from converter.py
from converter import FileConverter, SUPPORTED_CONVERSIONS

# Server Configuration
HOST = "localhost"
PORT = 8000
OUTPUT_DIR = "output"

# HTML Template with simple, clean, vanilla styling
HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple File Converter Web Tool</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px auto;
            max-width: 780px;
            padding: 0 20px;
            color: #222;
            background-color: #f7f9fa;
            line-height: 1.6;
        }
        .header {
            background-color: #ffffff;
            padding: 20px 25px;
            border-radius: 8px;
            border: 1px solid #ddd;
            margin-bottom: 20px;
        }
        h1 {
            color: #1a56db;
            margin: 0 0 8px 0;
            font-size: 24px;
        }
        .subtitle {
            color: #555;
            margin: 0;
            font-size: 14px;
        }
        .card {
            background-color: #ffffff;
            padding: 25px;
            border-radius: 8px;
            border: 1px solid #ddd;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 18px;
        }
        label {
            display: block;
            font-weight: bold;
            margin-bottom: 6px;
            font-size: 14px;
        }
        input[type="text"], select, textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
            box-sizing: border-box;
            font-family: inherit;
        }
        textarea {
            font-family: monospace;
            resize: vertical;
            height: 120px;
        }
        .btn {
            background-color: #1a56db;
            color: white;
            border: none;
            padding: 11px 22px;
            font-size: 15px;
            font-weight: bold;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #1e429f;
        }
        .btn-download {
            background-color: #057a55;
            text-decoration: none;
            display: inline-block;
            margin-top: 10px;
        }
        .btn-download:hover {
            background-color: #046c4e;
        }
        .alert {
            padding: 12px 16px;
            border-radius: 4px;
            margin-bottom: 18px;
            font-size: 14px;
        }
        .alert-success {
            background-color: #def7ec;
            color: #03543f;
            border: 1px solid #bcf0da;
        }
        .alert-error {
            background-color: #fde8e8;
            color: #9b1c1c;
            border: 1px solid #fbd5d5;
        }
        .summary-box {
            background-color: #f3f4f6;
            padding: 12px 15px;
            border-radius: 4px;
            font-size: 13px;
            margin-bottom: 12px;
        }
        .summary-box ul {
            margin: 6px 0 0 0;
            padding-left: 20px;
        }
        .footer {
            text-align: center;
            font-size: 12px;
            color: #777;
            margin-top: 30px;
        }
        .sample-note {
            font-size: 12px;
            color: #666;
            margin-top: 4px;
        }
    </style>
</head>
<body>

    <div class="header">
        <h1>Simple File Converter Web Tool</h1>
        <p class="subtitle">First-Year Python Project • Built using Python Standard Library only</p>
    </div>

    <!-- Alert / Message section -->
    __MESSAGE_SECTION__

    <div class="card">
        <form method="POST" action="/convert">
            <div class="form-group">
                <label for="file_input">1. Choose a Local File (TXT, CSV, JSON):</label>
                <input type="file" id="file_input" accept=".txt,.csv,.json">
                <p class="sample-note">Tip: Selecting a file will automatically load its name and content below.</p>
            </div>

            <div class="form-group">
                <label for="filename">Filename:</label>
                <input type="text" id="filename" name="filename" value="__FILENAME__" placeholder="example: sample.txt" required>
            </div>

            <div class="form-group">
                <label for="conversion_type">2. Select Conversion Type:</label>
                <select id="conversion_type" name="conversion_type" required>
                    __CONVERSION_OPTIONS__
                </select>
            </div>

            <div class="form-group">
                <label for="file_content">3. File Content (or paste directly):</label>
                <textarea id="file_content" name="file_content" placeholder="Paste or type text content here..." required>__FILE_CONTENT__</textarea>
            </div>

            <button type="submit" class="btn">Convert File</button>
        </form>
    </div>

    <!-- Result / Output Section -->
    __OUTPUT_SECTION__

    <div class="footer">
        <p>Python Essentials Course Project • Demonstrating OOP, Functions, Data Structures & Standard Modules</p>
    </div>

    <script>
        // Simple client-side reader to load file text into the form without any third-party framework
        document.getElementById('file_input').addEventListener('change', function(event) {
            var file = event.target.files[0];
            if (file) {
                document.getElementById('filename').value = file.name;
                var reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('file_content').value = e.target.result;
                };
                reader.readAsText(file);
            }
        });
    </script>
</body>
</html>
"""


class SimpleConverterHandler(BaseHTTPRequestHandler):
    """
    HTTP Request Handler built on Python's standard BaseHTTPRequestHandler.
    Handles GET requests (renders the interface) and POST requests (executes conversion).
    """

    def do_GET(self):
        """Serves the main converter web page."""
        self.send_response(200)
        self.send_header("Content-type", "text/html; charset=utf-8")
        self.end_headers()

        # Render page without messages
        html = self.render_html()
        self.wfile.write(html.encode("utf-8"))

    def do_POST(self):
        """Processes form submissions for file conversion."""
        content_length = int(self.headers.get("Content-Length", 0))
        post_data = self.rfile.read(content_length).decode("utf-8")

        # Parse application/x-www-form-urlencoded data
        parsed_params = urllib.parse.parse_qs(post_data)

        filename = parsed_params.get("filename", [""])[0].strip()
        conversion_type = parsed_params.get("conversion_type", [""])[0].strip()
        file_content = parsed_params.get("file_content", [""])[0]

        # Use our FileConverter class (demonstrating OOP)
        converter = FileConverter(
            filename=filename,
            file_content=file_content,
            conversion_type=conversion_type
        )

        success = converter.convert()

        message = ""
        output_section = ""

        if success:
            # Save converted file to the output directory
            save_ok, save_msg = converter.save(OUTPUT_DIR)
            summary = converter.get_summary()

            message = f'<div class="alert alert-success">{converter.message}</div>'

            # Build download link using data URL (works 100% in browser, no external service)
            encoded_content = urllib.parse.quote(converter.converted_content)
            download_link = (
                f'<a class="btn btn-download" '
                f'href="data:text/plain;charset=utf-8,{encoded_content}" '
                f'download="{converter.output_filename}">Download Converted File</a>'
            )

            output_section = f"""
            <div class="card">
                <h2>Conversion Result: {converter.output_filename}</h2>
                <div class="summary-box">
                    <strong>Summary & Statistics:</strong>
                    <ul>
                        <li><strong>Original File:</strong> {summary['original_filename']}</li>
                        <li><strong>Output File:</strong> {summary['output_filename']}</li>
                        <li><strong>Conversion:</strong> {summary['conversion_type']}</li>
                        <li><strong>Total Output Lines:</strong> {summary['output_lines']}</li>
                        <li><strong>Total Characters:</strong> {summary['output_characters']}</li>
                        <li><strong>Average Line Length:</strong> {summary['average_line_length']} chars</li>
                        <li><strong>Saved to Disk:</strong> {save_msg}</li>
                    </ul>
                </div>
                <div class="form-group">
                    <label>Converted Content Preview:</label>
                    <textarea readonly style="height: 180px;">{converter.converted_content}</textarea>
                </div>
                {download_link}
            </div>
            """
        else:
            message = f'<div class="alert alert-error">{converter.message}</div>'

        # Send back the response with updated messages and output
        self.send_response(200)
        self.send_header("Content-type", "text/html; charset=utf-8")
        self.end_headers()

        response_html = self.render_html(
            message=message,
            output_section=output_section,
            filename=filename,
            file_content=file_content,
            selected_type=conversion_type
        )
        self.wfile.write(response_html.encode("utf-8"))

    def render_html(self, message="", output_section="", filename="", file_content="", selected_type=""):
        """
        Renders the HTML template with the options and current state.
        Demonstrates loops, tuples, and string formatting.
        """
        options_html = []
        # Looping through tuples in SUPPORTED_CONVERSIONS
        for val, label in SUPPORTED_CONVERSIONS:
            is_selected = "selected" if val == selected_type else ""
            options_html.append(f'<option value="{val}" {is_selected}>{label}</option>')

        rendered = HTML_TEMPLATE.replace("__MESSAGE_SECTION__", message)
        rendered = rendered.replace("__OUTPUT_SECTION__", output_section)
        rendered = rendered.replace("__FILENAME__", filename)
        rendered = rendered.replace("__FILE_CONTENT__", file_content)
        rendered = rendered.replace("__CONVERSION_OPTIONS__", "\n".join(options_html))
        return rendered


def main():
    """Main entrypoint to start the local web server."""
    # Ensure output directory exists using standard os module
    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)

    server_address = (HOST, PORT)
    httpd = HTTPServer(server_address, SimpleConverterHandler)
    print("=" * 60)
    print(" Simple File Converter Web Tool")
    print(f" Server running at: http://{HOST}:{PORT}/")
    print(f" Converted files will be saved in: ./{OUTPUT_DIR}/")
    print(" Press Ctrl+C in this terminal to stop the server.")
    print("=" * 60)

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down server gracefully...")
        httpd.server_close()
        print("Server stopped.")


if __name__ == "__main__":
    main()
