# Simple File Converter Web Tool
**Academic Project for Python Essentials (First-Year Evaluation)**

---

## 1. Project Title & Description
**Title:** Simple File Converter Web Tool  
**Description:** A lightweight, beginner-friendly web application developed entirely in Python using only standard library modules. This project allows users to upload or paste text-based files and convert between **TXT**, **CSV**, and **JSON** formats locally through their web browser.

The project demonstrates core programming concepts taught in a first-year Python course, including Object-Oriented Programming (OOP), standard data structures, control flow, functions, file input/output, and clean error handling without any external third-party frameworks.

---

## 2. Key Features
- **Local Web Interface:** Runs locally on your machine via Python's built-in `http.server`.
- **Zero Third-Party Dependencies:** No Flask, Django, Pandas, or npm packages required. 100% Python standard library.
- **6 Essential Conversions:**
  1. Plain Text to Comma-Separated Values (`TXT → CSV`)
  2. Comma-Separated Values to Plain Text (`CSV → TXT`)
  3. Plain Text to Structured JSON (`TXT → JSON`)
  4. Structured JSON to Plain Text (`JSON → TXT`)
  5. Comma-Separated Values to JSON (`CSV → JSON`)
  6. Structured JSON to Comma-Separated Values (`JSON → CSV`)
- **Direct Local File Processing:** Users can either choose a local file from disk or paste text directly into the web interface.
- **Immediate In-Browser Download:** Converted files can be directly downloaded or saved into the local `./output/` directory.
- **Conversion Summary & Line Statistics:** Automatically computes line count, character count, and average line length using standard array structures and arithmetic operators.
- **Beginner-Friendly Error Handling:** Clear, understandable error messages for empty inputs, invalid JSON formatting, or mismatched extensions.

---

## 3. Technologies Used
- **Programming Language:** Python 3 (Tested on Python 3.13)
- **Standard Library Modules:**
  - `http.server`: Implements the local HTTP web server (`BaseHTTPRequestHandler`, `HTTPServer`).
  - `urllib.parse`: Parses URL query strings and form parameters.
  - `csv`: Reads and writes structured CSV data using `csv.reader`, `csv.writer`, `csv.DictReader`, and `csv.DictWriter`.
  - `json`: Parses and formats JSON data using `json.loads()` and `json.dumps()`.
  - `io`: In-memory text stream manipulation via `io.StringIO`.
  - `os`: File path operations and directory creation.
  - `array`: Efficient numeric array data structure to store line lengths for statistics.
- **Web Frontend:** Vanilla HTML5, minimal inline CSS, and a small client-side `FileReader` script.

---

## 4. Python Version
- **Target Version:** Python 3.8+ (Works on Python 3.10, 3.11, 3.12, and 3.13)
- Tested and verified on **Python 3.13.14**.

---

## 5. Project Structure
```text
file-converter/
│
├── app.py                  # Entrypoint: Local HTTP web server and request routing
├── converter.py            # Core conversion logic, FileConverter class, and data structures
├── test_converter.py       # Automated test suite using Python's assert statements
├── requirements.txt        # Documents zero external pip dependencies
├── README.md               # Detailed academic project documentation
├── sample_files/           # Test sample files provided for evaluation
│   ├── sample.txt          # Sample plain text file
│   ├── sample.csv          # Sample CSV table with student records
│   └── sample.json         # Sample JSON array of course records
└── output/                 # Destination folder where converted files are saved
    └── .gitkeep            # Placeholder to track output directory in git
```

---

## 6. How to Install Python
1. Visit the official Python website: [https://www.python.org/downloads/](https://www.python.org/downloads/)
2. Download the latest Python 3 installer for Windows, macOS, or Linux.
3. **Important on Windows:** During installation, check the box that says **"Add python.exe to PATH"**.
4. Verify installation in your terminal:
   ```bash
   python --version
   ```

---

## 7. How to Download the Project
1. Extract or place the `file-converter` directory into your workspace:
   `C:\Users\manvi\.gemini\antigravity\scratch\file-converter`
2. Open your terminal or command prompt in that directory:
   ```bash
   cd C:\Users\manvi\.gemini\antigravity\scratch\file-converter
   ```

---

## 8. Virtual Environment & Dependencies
Since this project **strictly uses the Python standard library**, you do not need to install any external packages!
- To create a virtual environment (optional standard practice):
  ```bash
  python -m venv venv
  ```
- To activate it:
  - **Windows (Command Prompt / PowerShell):**
    ```powershell
    .\venv\Scripts\activate
    ```
  - **macOS / Linux:**
    ```bash
    source venv/bin/activate
    ```
- Dependencies installation:
  ```bash
  pip install -r requirements.txt
  ```
  *(Note: `requirements.txt` contains only comments confirming zero third-party packages are needed).*

---

## 9. How to Run the Project
1. Open your terminal in the project folder.
2. Start the application:
   ```bash
   python app.py
   ```
3. You will see terminal output indicating the server is running:
   ```text
   ============================================================
    Simple File Converter Web Tool
    Server running at: http://localhost:8000/
    Converted files will be saved in: ./output/
    Press Ctrl+C in this terminal to stop the server.
   ============================================================
   ```
4. Open your web browser and navigate to:
   [**http://localhost:8000**](http://localhost:8000)
5. To stop the server when finished, press `Ctrl + C` in the terminal.

---

## 10. How to Use the File Converter
1. **Select a File:** Click the **Choose File** button to select a local `.txt`, `.csv`, or `.json` file (you can use files from `sample_files/`).
2. **Review/Edit Content:** The file content will automatically populate into the text area. You can also paste or modify content manually.
3. **Select Conversion Type:** Choose the conversion from the dropdown menu (e.g., *CSV to JSON*).
4. **Click Convert File:** The application processes the data and displays:
   - A success or error notification banner.
   - A summary box showing the original file name, output file name, line count, character count, and average line length.
   - A preview of the converted text.
5. **Download:** Click the green **Download Converted File** button to save the converted file to your browser's download folder. The file is also saved on disk inside the `./output/` directory.

---

## 11. Supported Conversions & Logic

| Conversion | Description | Python Module Used |
| :--- | :--- | :--- |
| **TXT → CSV** | Converts lines of text into numbered CSV rows (`Line_Number, Text_Content`). | `csv.writer` |
| **CSV → TXT** | Reads CSV rows and converts them into readable text separated by ` \| `. | `csv.reader` |
| **TXT → JSON** | Converts lines of text into a structured JSON array of objects with line numbers and character counts. | `json.dumps` |
| **JSON → TXT** | Parses JSON arrays or objects and converts each item into human-readable text lines. | `json.loads` |
| **CSV → JSON** | Reads CSV header columns and converts each data row into a JSON object dictionary. | `csv.DictReader`, `json.dumps` |
| **JSON → CSV** | Extracts dictionary keys as CSV headers and writes each object as a corresponding CSV row. | `json.loads`, `csv.DictWriter` |

---

## 12. Example Inputs and Outputs

### Example 1: `CSV → JSON`
**Input (`sample.csv`):**
```csv
StudentID,Name,Course,Grade
101,Aarav Sharma,Python Essentials,92
102,Diya Patel,Python Essentials,88
```
**Output (`sample_converted.json`):**
```json
[
    {
        "StudentID": "101",
        "Name": "Aarav Sharma",
        "Course": "Python Essentials",
        "Grade": "92"
    },
    {
        "StudentID": "102",
        "Name": "Diya Patel",
        "Course": "Python Essentials",
        "Grade": "88"
    }
]
```

### Example 2: `TXT → CSV`
**Input (`sample.txt`):**
```text
Python Essentials Course
First-Year Project
Simple File Converter
```
**Output (`sample_converted.csv`):**
```csv
Line_Number,Text_Content
1,Python Essentials Course
2,First-Year Project
3,Simple File Converter
```

---

## 13. Course Concepts Demonstrated

Every concept required by the course syllabus has been intentionally implemented:

1. **Python Fundamentals:**
   - Clear variable names, readable scripts, module docstrings, and comments.
2. **Membership Operators (`in`, `not in`):**
   - Checking valid file extensions: `if "." in filename:`
   - Validating conversion choice: `if conversion_type not in CONVERSION_MAP:`
3. **Assignment Operators (`=`, `+=`):**
   - Accumulating line numbers: `line_num += 1`
   - Accumulating character totals: `total_chars += length`
4. **Relational / Comparison Operators (`==`, `!=`, `>`, `<`):**
   - Validating lengths and comparisons: `if len(row) == 0:`, `if total_lines > 0:`
5. **Logical Operators (`and`, `or`, `not`):**
   - Combining validation rules: `if not filename or len(filename.strip()) == 0:`
   - Multiple criteria: `if "Age" in result and "Name" in result:`
6. **Arithmetic Operators (`+`, `/`):**
   - String concatenation: `base_name + "_converted." + target_ext`
   - Division with mixed data types: `avg_line_length = total_chars / total_lines` (computes float from integers).
7. **`type()` Function & Identity Operators (`is`, `is not`):**
   - Checking data structures during JSON parsing: `if type(data) is list:`, `if type(item) is not dict:`
   - Checking against `None`: `if self.converted_content is None:`
8. **Type Conversion (`str()`, `int()`, `float()`, `round()`):**
   - Casting inputs: `content_length = int(self.headers.get("Content-Length", 0))`
   - Rounding float averages: `round(avg_len, 2)`
9. **Data Structures:**
   - **Lists:** Storing row records (`rows_list = []`), collecting lines (`lines = []`).
   - **Tuples:** Fixed options that should not be modified: `SUPPORTED_CONVERSIONS = (("txt_to_csv", ...), ...)`.
   - **Sets:** Fast unique collection for column headers: `fieldnames_set = set()`.
   - **Dictionaries:** Configuration lookup tables (`CONVERSION_MAP`) and JSON records.
   - **Frozen Sets:** Permanent unchangeable categories: `FROZEN_VALID_FORMATS = frozenset(["txt", "csv", "json"])`.
   - **Array Data Structure:** Standard `array.array('i')` used in `calculate_line_statistics()` to store line lengths.
10. **Control Flow:**
    - `if / elif / else` branching in conversion dispatch.
    - `for` loops iterating over lines, rows, and dictionary entries.
11. **Functions:**
    - Modular, single-purpose functions: `convert_txt_to_csv()`, `convert_csv_to_json()`, `validate_file()`, etc.
12. **Object-Oriented Programming (OOP):**
    - One clean class `FileConverter` encapsulating file attributes, validation (`.validate()`), execution (`.convert()`), summary generation (`.get_summary()`), and disk saving (`.save()`).
13. **Input and Output Operations:**
    - Opening and writing files with `open(output_path, "w", encoding="utf-8")`.

---

## 14. How to Run the Automated Tests
A dedicated test suite is included in `test_converter.py` to verify all 6 conversions, error handling, and class methods.

To execute tests:
```bash
python test_converter.py
```

Expected output:
```text
============================================================
Running Tests for Simple File Converter
============================================================
Testing 1: TXT to CSV... PASSED
Testing 2: CSV to TXT... PASSED
Testing 3: TXT to JSON... PASSED
Testing 4: JSON to TXT... PASSED
Testing 5: CSV to JSON... PASSED
Testing 6: JSON to CSV... PASSED
Testing 7: FileConverter Class & OOP... PASSED
Testing 8: Error Handling & Validation... PASSED
Testing 9: Statistics & Array structure... PASSED
============================================================
ALL 9 TESTS PASSED SUCCESSFULLY! (100% OK)
============================================================
```

---

## 15. Common Errors & Troubleshooting

| Error Message | Cause | Solution |
| :--- | :--- | :--- |
| `Error: No filename was provided.` | The filename field was left blank. | Enter a filename (e.g. `data.csv`). |
| `Error: The provided file content is empty.` | The text area has no content. | Select a file or paste text before converting. |
| `Error: Selected conversion requires a .csv file, but got .txt.` | File extension does not match the source format required by the conversion. | Choose the matching conversion type for your file extension. |
| `Error: Invalid JSON format` | The JSON text has missing brackets, quotes, or trailing commas. | Verify the JSON syntax or use a sample from `sample_files/`. |
| `Address already in use` | Another program is already using port 8000. | Change `PORT = 8000` to `PORT = 8080` in `app.py`. |

---

## 16. Limitations
- **Text-Based Formats Only:** Only supports `TXT`, `CSV`, and `JSON`. Binary formats (PDF, DOCX, images) are deliberately excluded per the course syllabus.
- **Single-Threaded Academic Server:** Uses Python's standard `http.server`, which is intended for local academic evaluation and demonstrations, not high-traffic production workloads.
- **Memory-Based Processing:** Files are read into memory strings, suitable for typical document sizes (up to several megabytes).

---

## 17. Future Improvements
- Add support for TSV (Tab-Separated Values).
- Add an interactive visual preview toggle for CSV tables (rendering an HTML table grid).
- Provide a file comparison view between the original and converted text side-by-side.
- Add an option to sort or filter JSON keys alphabetically upon conversion.
