"""
test_converter.py
-----------------
Simple unit and integration tests for the File Converter project.
Uses Python's standard 'assert' statement without any external testing libraries.

To run:
    python test_converter.py
"""

import os
from converter import (
    FileConverter,
    convert_txt_to_csv,
    convert_csv_to_txt,
    convert_txt_to_json,
    convert_json_to_txt,
    convert_csv_to_json,
    convert_json_to_csv,
    validate_file,
    calculate_line_statistics
)


def test_txt_to_csv():
    print("Testing 1: TXT to CSV...", end=" ")
    raw_txt = "First Line\nSecond Line\nThird Line"
    result = convert_txt_to_csv(raw_txt)
    assert "Line_Number,Text_Content" in result, "Header missing in TXT to CSV"
    assert "1,First Line" in result, "Line 1 content missing"
    assert "2,Second Line" in result, "Line 2 content missing"
    print("PASSED")


def test_csv_to_txt():
    print("Testing 2: CSV to TXT...", end=" ")
    raw_csv = "Name,Score\nAlice,95\nBob,88"
    result = convert_csv_to_txt(raw_csv)
    assert "Name | Score" in result, "CSV to TXT header failed"
    assert "Alice | 95" in result, "Row 1 failed"
    print("PASSED")


def test_txt_to_json():
    print("Testing 3: TXT to JSON...", end=" ")
    raw_txt = "Apple\nBanana\nCherry"
    result = convert_txt_to_json(raw_txt)
    assert '"line": 1' in result, "Line number missing in JSON"
    assert '"text": "Apple"' in result, "Apple text missing in JSON"
    assert '"length": 5' in result, "Length missing in JSON"
    print("PASSED")


def test_json_to_txt():
    print("Testing 4: JSON to TXT...", end=" ")
    raw_json = '[{"item": "Pen", "price": 10}, {"item": "Book", "price": 50}]'
    result = convert_json_to_txt(raw_json)
    assert "item: Pen" in result, "Pen entry missing"
    assert "price: 50" in result, "Price entry missing"
    print("PASSED")


def test_csv_to_json():
    print("Testing 5: CSV to JSON...", end=" ")
    raw_csv = "City,Country\nTokyo,Japan\nParis,France"
    result = convert_csv_to_json(raw_csv)
    assert '"City": "Tokyo"' in result, "Tokyo entry missing"
    assert '"Country": "France"' in result, "France entry missing"
    print("PASSED")


def test_json_to_csv():
    print("Testing 6: JSON to CSV...", end=" ")
    raw_json = '[{"Name": "Charlie", "Age": 21}, {"Name": "Dana", "Age": 22}]'
    result = convert_json_to_csv(raw_json)
    assert "Age" in result and "Name" in result, "CSV headers missing"
    assert "Charlie" in result, "Charlie data missing"
    assert "Dana" in result, "Dana data missing"
    print("PASSED")


def test_file_converter_class():
    print("Testing 7: FileConverter Class & OOP...", end=" ")
    converter = FileConverter(
        filename="test_notes.txt",
        file_content="Line one\nLine two",
        conversion_type="txt_to_csv"
    )
    success = converter.convert()
    assert success is True, "Converter execution failed"
    assert converter.output_filename == "test_notes_converted.csv"
    assert converter.is_successful is True

    summary = converter.get_summary()
    assert summary["original_filename"] == "test_notes.txt"
    assert summary["output_lines"] > 0
    assert summary["output_characters"] > 0

    # Test file saving
    save_success, save_path = converter.save(output_directory="output")
    assert save_success is True, "Saving output file failed"
    assert os.path.exists(save_path), "Saved file does not exist on disk"

    # Clean up test output
    if os.path.exists(save_path):
        os.remove(save_path)
    print("PASSED")


def test_error_handling():
    print("Testing 8: Error Handling & Validation...", end=" ")
    # 1. Empty filename
    valid, msg = validate_file("", "Some content", "txt_to_csv")
    assert valid is False, "Empty filename should fail validation"

    # 2. Empty content
    valid, msg = validate_file("test.txt", "   ", "txt_to_csv")
    assert valid is False, "Empty content should fail validation"

    # 3. Invalid conversion choice
    valid, msg = validate_file("test.txt", "Content", "invalid_choice")
    assert valid is False, "Invalid conversion choice should fail validation"

    # 4. Mismatched file extension
    valid, msg = validate_file("data.csv", "Content", "txt_to_csv")
    assert valid is False, "Mismatched extension should fail validation"

    # 5. Invalid JSON syntax
    bad_json = '{"broken": [1, 2, }'
    err_txt = convert_json_to_txt(bad_json)
    assert "Error: Invalid JSON format" in err_txt, "Invalid JSON should return error"

    err_csv = convert_json_to_csv(bad_json)
    assert "Error: Invalid JSON format" in err_csv, "Invalid JSON should return error"
    print("PASSED")


def test_statistics_and_array():
    print("Testing 9: Statistics & Array structure...", end=" ")
    text = "Short\nMedium length line\nA"
    lines, chars, avg_len = calculate_line_statistics(text)
    assert lines == 3, "Line count calculation incorrect"
    assert chars == len("Short") + len("Medium length line") + len("A")
    assert avg_len > 0.0, "Average length should be a positive float"
    print("PASSED")


def run_all_tests():
    print("=" * 60)
    print("Running Tests for Simple File Converter")
    print("=" * 60)
    test_txt_to_csv()
    test_csv_to_txt()
    test_txt_to_json()
    test_json_to_txt()
    test_csv_to_json()
    test_json_to_csv()
    test_file_converter_class()
    test_error_handling()
    test_statistics_and_array()
    print("=" * 60)
    print("ALL 9 TESTS PASSED SUCCESSFULLY! (100% OK)")
    print("=" * 60)


if __name__ == "__main__":
    run_all_tests()
