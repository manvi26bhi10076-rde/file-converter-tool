"""
converter.py
------------
Simple File Converter Module for First-Year Python Essentials Project.

This module provides:
1. Functions for 6 text-based conversions:
   - TXT to CSV
   - CSV to TXT
   - TXT to JSON
   - JSON to TXT
   - CSV to JSON
   - JSON to CSV
2. A single simple class: FileConverter (demonstrating basic OOP)
3. Demonstration of course concepts:
   - Data structures: Lists, Tuples, Sets, Dictionaries, Frozen sets, Array
   - Operators: arithmetic, relational, logical, membership, identity, assignment
   - Type conversion and type() inspection
"""

import csv
import io
import json
import os
import array  # Standard library array data structure

# --- Course Data Structures: Constants and Configurations ---

# Tuple: An ordered, immutable collection for fixed conversion choices
SUPPORTED_CONVERSIONS = (
    ("txt_to_csv", "TXT to CSV"),
    ("csv_to_txt", "CSV to TXT"),
    ("txt_to_json", "TXT to JSON"),
    ("json_to_txt", "JSON to TXT"),
    ("csv_to_json", "CSV to JSON"),
    ("json_to_csv", "JSON to CSV")
)

# Set: A mutable collection of unique items for fast membership checks
SUPPORTED_EXTENSIONS = {"txt", "csv", "json"}

# Frozen Set: An immutable set for permanent, unchangeable format categories
FROZEN_VALID_FORMATS = frozenset(["txt", "csv", "json"])

# Dictionary: Maps conversion types to their expected input and output file extensions
CONVERSION_MAP = {
    "txt_to_csv": {"source": "txt", "target": "csv"},
    "csv_to_txt": {"source": "csv", "target": "txt"},
    "txt_to_json": {"source": "txt", "target": "json"},
    "json_to_txt": {"source": "json", "target": "txt"},
    "csv_to_json": {"source": "csv", "target": "json"},
    "json_to_csv": {"source": "json", "target": "csv"}
}


# --- Helper Functions ---

def get_file_extension(filename):
    """
    Extracts the lowercase file extension from a filename.
    Uses basic string manipulation and membership operators.
    """
    if "." in filename:
        parts = filename.split(".")
        return parts[-1].lower()
    return ""


def validate_file(filename, content, conversion_type):
    """
    Validates the input file and conversion choice.
    Returns a tuple: (is_valid: bool, error_message: str)
    Demonstrates logical AND/OR/NOT, relational and membership operators.
    """
    # Check if a filename was provided
    if not filename or len(filename.strip()) == 0:
        return (False, "Error: No filename was provided.")

    # Check if content is empty (relational operator and type check)
    if content is None or len(content.strip()) == 0:
        return (False, "Error: The provided file content is empty.")

    # Membership operator check on dictionary keys
    if conversion_type not in CONVERSION_MAP:
        return (False, "Error: Invalid conversion choice selected.")

    # Check extension matching using relational operators and dictionary lookup
    file_ext = get_file_extension(filename)
    expected_source = CONVERSION_MAP[conversion_type]["source"]

    # If the file has an extension, verify it matches the required source format
    if file_ext != "" and file_ext != expected_source:
        return (
            False,
            f"Error: Selected conversion requires a .{expected_source} file, but got .{file_ext}."
        )

    return (True, "")


def calculate_line_statistics(text_content):
    """
    Demonstrates the Python standard library 'array' data structure,
    arithmetic operators, and mixed data type division.
    """
    lines = text_content.strip().splitlines()
    total_lines = len(lines)

    if total_lines == 0:
        return 0, 0, 0.0

    # Using standard library array of integers ('i') to store line lengths
    line_lengths = array.array('i')
    total_chars = 0

    for line in lines:
        length = len(line)
        line_lengths.append(length)
        total_chars += length  # Assignment operator

    # Mixed data type division: integer / integer gives float
    avg_line_length = total_chars / total_lines

    return total_lines, total_chars, avg_line_length


# --- Core Conversion Functions ---

def convert_txt_to_csv(txt_content):
    """
    Converts plain text into CSV format.
    Each non-empty line becomes a numbered row: Line,Content
    """
    lines = txt_content.strip().splitlines()
    output = io.StringIO()
    writer = csv.writer(output)

    # Write CSV header row
    writer.writerow(["Line_Number", "Text_Content"])

    line_num = 1  # Integer counter
    for line in lines:
        cleaned_line = line.strip()
        # Logical NOT operator
        if not cleaned_line:
            continue
        writer.writerow([line_num, cleaned_line])
        line_num += 1  # Arithmetic assignment operator

    return output.getvalue()


def convert_csv_to_txt(csv_content):
    """
    Converts CSV format back into readable plain text.
    Reads each row and formats column values clearly.
    """
    input_stream = io.StringIO(csv_content.strip())
    reader = csv.reader(input_stream)

    text_lines = []  # List data structure
    row_count = 0

    for row in reader:
        # Relational operator
        if len(row) == 0:
            continue
        row_count += 1
        # Join row elements with a separator
        formatted_row = " | ".join(row)
        text_lines.append(formatted_row)

    if len(text_lines) == 0:
        return "Empty CSV data."

    # Return plain text joined by newlines
    return "\n".join(text_lines)


def convert_txt_to_json(txt_content):
    """
    Converts plain text into a structured JSON list of objects.
    Each line is recorded with its line number and character count.
    """
    lines = txt_content.strip().splitlines()
    records = []  # List of dictionaries

    line_number = 1
    for line in lines:
        cleaned = line.strip()
        if len(cleaned) > 0:
            # Dictionary data structure
            item = {
                "line": line_number,
                "text": cleaned,
                "length": len(cleaned)
            }
            records.append(item)
            line_number += 1

    # Standard json module to format Python list of dicts to string
    return json.dumps(records, indent=4)


def convert_json_to_txt(json_content):
    """
    Converts JSON data (list or dictionary) into readable plain text.
    Demonstrates type() inspection and identity operators.
    """
    try:
        data = json.loads(json_content)
    except json.JSONDecodeError as err:
        return f"Error: Invalid JSON format ({str(err)})"

    text_output = []

    # Using type() function and identity operators (is / is not)
    if type(data) is list:
        for idx, entry in enumerate(data, start=1):
            if type(entry) is dict:
                # Format key-value pairs
                row_parts = [f"{k}: {v}" for k, v in entry.items()]
                text_output.append(f"[{idx}] " + ", ".join(row_parts))
            else:
                text_output.append(f"[{idx}] {str(entry)}")
    elif type(data) is dict:
        for key, value in data.items():
            text_output.append(f"{key}: {value}")
    else:
        text_output.append(str(data))

    return "\n".join(text_output)


def convert_csv_to_json(csv_content):
    """
    Converts CSV text with header row into a formatted JSON array of records.
    Uses csv.DictReader and json.dumps.
    """
    input_stream = io.StringIO(csv_content.strip())
    reader = csv.DictReader(input_stream)

    rows_list = []  # List of dictionaries
    for row in reader:
        # Clean dictionary keys and values
        clean_row = {str(k).strip(): str(v).strip() for k, v in row.items() if k is not None}
        if clean_row:
            rows_list.append(clean_row)

    if not rows_list:
        # Fallback if no header row was detected
        input_stream.seek(0)
        simple_reader = csv.reader(input_stream)
        for row in simple_reader:
            if row:
                rows_list.append({"columns": row})

    return json.dumps(rows_list, indent=4)


def convert_json_to_csv(json_content):
    """
    Converts a JSON array of objects into standard CSV format.
    Extracts dictionary keys as CSV headers and values as CSV rows.
    """
    try:
        data = json.loads(json_content)
    except json.JSONDecodeError as err:
        return f"Error: Invalid JSON format ({str(err)})"

    # Validate that data is a list
    if type(data) is not list:
        # If single dictionary, wrap it into a list
        if type(data) is dict:
            data = [data]
        else:
            return "Error: JSON must be an array of objects to convert to CSV."

    if len(data) == 0:
        return "Error: JSON array is empty."

    # Collect all unique fieldnames using a set
    fieldnames_set = set()
    for item in data:
        if type(item) is dict:
            for key in item.keys():
                fieldnames_set.add(key)

    if not fieldnames_set:
        return "Error: No object keys found in JSON data."

    # Convert set to sorted list for consistent column order
    fieldnames = sorted(list(fieldnames_set))

    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=fieldnames)

    writer.writeheader()
    for item in data:
        if type(item) is dict:
            writer.writerow(item)

    return output.getvalue()


# --- Object-Oriented Programming: FileConverter Class ---

class FileConverter:
    """
    A single simple class demonstrating Object-Oriented Programming (OOP).

    Responsibilities:
    - Stores the file name, raw content, and requested conversion type.
    - Validates inputs before running conversion.
    - Executes the selected conversion function.
    - Provides a summary of the conversion result.
    - Saves the output to a specified directory.
    """

    def __init__(self, filename="", file_content="", conversion_type=""):
        # Instance attributes
        self.filename = filename
        self.file_content = file_content
        self.conversion_type = conversion_type
        self.converted_content = None
        self.output_filename = ""
        self.is_successful = False
        self.message = ""

    def validate(self):
        """Validates the converter instance inputs."""
        is_valid, err_msg = validate_file(
            self.filename,
            self.file_content,
            self.conversion_type
        )
        if not is_valid:
            self.message = err_msg
            self.is_successful = False
            return False
        return True

    def convert(self):
        """
        Executes the conversion based on self.conversion_type.
        Demonstrates if / elif / else control flow and dictionary routing.
        """
        if not self.validate():
            return False

        # Determine target extension
        target_ext = CONVERSION_MAP[self.conversion_type]["target"]
        base_name = os.path.splitext(self.filename)[0]
        if not base_name:
            base_name = "converted_file"
        self.output_filename = f"{base_name}_converted.{target_ext}"

        # Control flow statements
        if self.conversion_type == "txt_to_csv":
            self.converted_content = convert_txt_to_csv(self.file_content)
        elif self.conversion_type == "csv_to_txt":
            self.converted_content = convert_csv_to_txt(self.file_content)
        elif self.conversion_type == "txt_to_json":
            self.converted_content = convert_txt_to_json(self.file_content)
        elif self.conversion_type == "json_to_txt":
            self.converted_content = convert_json_to_txt(self.file_content)
        elif self.conversion_type == "csv_to_json":
            self.converted_content = convert_csv_to_json(self.file_content)
        elif self.conversion_type == "json_to_csv":
            self.converted_content = convert_json_to_csv(self.file_content)
        else:
            self.message = "Error: Unknown conversion type."
            self.is_successful = False
            return False

        # Check if the conversion function returned an error string
        if self.converted_content.startswith("Error:"):
            self.message = self.converted_content
            self.is_successful = False
            return False

        self.is_successful = True
        self.message = f"Success: Converted '{self.filename}' to '{self.output_filename}'!"
        return True

    def get_summary(self):
        """
        Returns a dictionary containing key statistics about the conversion.
        Demonstrates dictionary data structure and statistics calculation.
        """
        lines_count, char_count, avg_len = calculate_line_statistics(
            self.converted_content if self.converted_content else ""
        )

        return {
            "original_filename": self.filename,
            "output_filename": self.output_filename,
            "conversion_type": self.conversion_type,
            "is_successful": self.is_successful,
            "message": self.message,
            "output_lines": lines_count,
            "output_characters": char_count,
            "average_line_length": round(avg_len, 2)
        }

    def save(self, output_directory="output"):
        """
        Saves the converted content to a file in the output directory.
        Uses basic Python file I/O (open, write).
        """
        if not self.is_successful or self.converted_content is None:
            return False, "Cannot save: file has not been successfully converted."

        # Ensure directory exists
        if not os.path.exists(output_directory):
            os.makedirs(output_directory)

        output_path = os.path.join(output_directory, self.output_filename)

        # Standard file I/O operations
        with open(output_path, "w", encoding="utf-8") as out_file:
            out_file.write(self.converted_content)

        return True, output_path
